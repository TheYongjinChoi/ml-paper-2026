# 03_split.py — analytic samples, train/test split, preprocessor (notebook cell 9)
# Requires: df, pred_vars (from 02_recode.py)
# Produces: df_s1, df_s2, df_s3, samples (dict), preprocessor

df_s1 = df.dropna(subset=pred_vars + ["ptb"]).copy()
df_s2 = df_s1[df_s1["mager"] >= 40].reset_index(drop=True)
df_s3 = df_s1[df_s1["rf_ppterm"] == 1].reset_index(drop=True)

sample_sizes = pd.DataFrame({
    "sample": ["Initial", "1. All mothers (complete cases)", "2. Age 40+", "3. Previous PTB"],
    "n": [len(df), len(df_s1), len(df_s2), len(df_s3)],
})

# Predictors
numeric_cols = ["mager", "wtgain", "rf_cesarn", "cig_1", "cig_2", "cig_3", "m_ht_in", "bmi"]
cat_cols = ["wic",
            "mm_mtr", "mm_plac", "mm_rupt", "mm_uhyst", "mm_aicu",
            "ca_anen", "ca_mnsb", "ca_cchd", "ca_cdh", "ca_omph",
            "ca_gast", "ca_limb", "ca_cleft", "ca_clpal", "ca_down",
            "ca_disor", "ca_hypo",
            "rf_pdiab", "rf_gdiab", "rf_phype", "rf_ghype", "rf_ehype",
            "rf_ppterm", "rf_inftr", "rf_fedrg", "rf_artec",
            "dob_mm", "mbstate_rec", "restatus",
            "mrace31", "mhispx", "meduc",
            "lbo_rec", "tbo_rec", "priorlive", "priordead", "priorterm",
            "precare", "previs",
            "illb_r11", "ilop_r11", "ilp_r11"]

preprocessor = ColumnTransformer([
    ("num", "passthrough", numeric_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
])

# Splits ---------------------------------------------------------------
def _xy(train, test, outcome="ptb", dtype="float32"):
    return dict(
        X_train=train[pred_vars].astype(dtype), y_train=train[outcome].astype(int),
        X_test=test[pred_vars].astype(dtype),   y_test=test[outcome].astype(int),
    )

np.random.seed(SEED)
sample_size = 300_000
tr, te = train_test_split(df_s1, train_size=sample_size, test_size=sample_size,
                          random_state=SEED, shuffle=True)
s1 = _xy(tr.reset_index(drop=True), te.reset_index(drop=True))

tr, te = train_test_split(df_s2, test_size=0.2, random_state=SEED, shuffle=True)
s2 = _xy(tr.reset_index(drop=True), te.reset_index(drop=True))

tr, te = train_test_split(df_s3, test_size=0.2, random_state=SEED, shuffle=True)
s3 = _xy(tr.reset_index(drop=True), te.reset_index(drop=True))

samples = {1: s1, 2: s2, 3: s3}
del tr, te
