# PredBirths — Quarto (Python) analysis notebook

```
_quarto.yml            project config (execute-dir: project, freeze: auto)
_master.qmd            analysis notebook → HTML
code/
  00_setup.py          dependency check, packages, paths, scoring
  fields_nat2024.py    fixed-width layout (verbatim from the notebook)
  01_read_data.py      parse raw .txt → df, RECODE_SPEC
  02_recode.py         recode variables, cache parquet, var_summary
  03_split.py          samples 1–3, train/test, preprocessor
  04_cv.py             run_grid() / save_results() / load_latest()
data/                  Nat2024PublicUS.c20250512.r20250708.txt
outputs/               S{sample}_{model}_{date}.csv, figures, tbl2_perf_*.csv
```

Scripts are loaded with `%run -i code/xx.py`, which runs them in the notebook's
own namespace — the Python equivalent of R's `source()`. They therefore share
globals (`df`, `preprocessor`, `SEED`) and must run in order.

## One-time setup

1. Copy `Nat2024PublicUS.c20250512.r20250708.txt` into `data/`.
2. Make the tf-gpu environment visible to Quarto as a Jupyter kernel
   (run inside that env):

   ```bash
   pip install jupyter ipykernel pyarrow
   python -m ipykernel install --user --name tf-gpu --display-name "tf-gpu"
   ```

   then set `jupyter: tf-gpu` in `_quarto.yml`. Check with `quarto check jupyter`.

## Running

```bash
quarto render _master.qmd                                  # reads raw data, loads saved results
quarto render _master.qmd -P RUN_MODELS:true -P SAMPLE:3   # retrain all models for sample 3
quarto preview _master.qmd                                 # live preview while editing
```

Every render re-parses the raw file (several minutes). `02_recode.py` still
writes `data/nat2024_recoded.parquet`, so the read step can be skipped by
replacing the `data-prep` chunk with:

```python
if DATA_CACHE.exists():
    df = pd.read_parquet(DATA_CACHE)
    target_vars = list(df.columns)
    pred_vars = [v for v in target_vars if v not in ["ptb", "lbw", "combgest", "dbwt"]]
    var_summary = ...
else:
    %run -i code/01_read_data.py
    %run -i code/02_recode.py
```

Interactive work: open `_master.qmd` in Positron or VS Code (Quarto extension)
and run cells with Shift+Enter — same kernel, same `%run` calls.
